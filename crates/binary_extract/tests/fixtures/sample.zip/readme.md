# binary_extract

> utilities for the `@monots/binary-install` module

This crate provides a method for deleting a folder recursively and also for extracting a tarball or zip archive.
